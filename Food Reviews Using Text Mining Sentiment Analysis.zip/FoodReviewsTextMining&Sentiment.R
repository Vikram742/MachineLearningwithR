# set the working directory and read the data
library(readxl)
food<- read_excel("FoodReviews.xlsx")
head(food,5)
#data cleaning
str(food)
sum(is.na(food))
#Run the required libraries
library(tm)
library(SnowballC)
library(dplyr)
library(sentimentr)
library(wordcloud2)
library(RColorBrewer)

######### Text acquisition and aggregation. Create corpus. 
food_doc<- Corpus(VectorSource(food$Text))
inspect(food_doc)
######### Text Pre-processing. Cleaning the text
# Replace special characters with " "
toSpace<- content_transformer(function(x,pattern) gsub(pattern, " ",x))
food_doc<-tm_map(food_doc,toSpace,"/")
food_doc<-tm_map(food_doc,toSpace,"@")
food_doc <- tm_map(food_doc, toSpace, "\\|")

#make all the alphabets lower case
food_doc<- tm_map(food_doc,content_transformer(tolower))
#remove punctuations
food_doc<- tm_map(food_doc,removePunctuation)
#remove whitespace
food_doc<-tm_map(food_doc, stripWhitespace)
#remove stopwords
food_doc<- tm_map(food_doc,removeWords,stopwords("english"))
#remove numbers
food_doc<-tm_map(food_doc,removeNumbers)
#stemming
food_doc<-tm_map(food_doc,stemDocument)

#create term document matrix
tdm<- TermDocumentMatrix(food_doc)
tdm
#convert into matrix and find out frequency of words
tdm_m<- as.matrix(tdm)
tdm_m[1:10,1:20]
#sort by decreasing value of frequency
tdm_f<- sort(rowSums(tdm_m),decreasing = TRUE)
#convert into data frame
tdm_d<- data.frame(word = names(tdm_f), freq = tdm_f)
#find out the words which appear most frequently
head(tdm_d,10)
# like : 2295 , tast : 2093 , flavor : 1840
#find out the words which appear least frequently
tail(tdm_d,10)
#caveman , huntergather, primal : 1

####### TEXT EXPLORATION
# plot barchart for most frequently occured words
barplot(tdm_d[1:5,]$freq, las = 2, names.arg = tdm_d[1:5,]$word, col = "green",
        main = "Top 5 frequently occurred words", xlab = "word" , ylab = "count")

#create wordcloud
set.seed(1234)
wordcloud2(tdm_d, shape = "triangle", size = 0.4)

######## TEXT MODELLING
## word association

findAssocs(tdm, terms= c("like","tast","flavor"), corlimit = 0.20)
# "like" has an association with "realli" (they appear about 25% of the time together), dont (24%), one(21%)
# "tast" does not have an association with any word with the set correlation limit
# "flavor" has an association with the word "chip"(they appear about 27% of the time together)

## sentiment analysis
sentiment_scores<- sentimentr::sentiment(food$Text)
options(scipen=10)
sentiment_scores

doc_polarity_score<-mean(sentiment_scores$sentiment)
  doc_polarity_score #0.15 is the overall sentiment score. This indicates that the entire food review document has
  # a marginally positive score

review_sentiment_score<- sentiment_scores %>% 
  group_by(element_id) %>% 
  summarise(word_count = sum(word_count), avg_sentiment = mean(sentiment))

review_sentiment_score
# -1 indicates the most extreme negative sentiment and +1 indicates the most extreme positive sentiment

rr<- review_sentiment_score %>% 
  filter(avg_sentiment<0) 
# 726 negative sentiments have been found out of the total 5000 sentiments  
