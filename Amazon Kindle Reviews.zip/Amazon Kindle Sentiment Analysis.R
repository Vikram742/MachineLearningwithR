library(tm)
library(wordcloud)
library(wordcloud2)
library(RColorBrewer)
library(syuzhet)
library(SnowballC)
library(sentimentr)

#read the data
amazon<-read.csv("preprocessed_kindle_review .csv", stringsAsFactors = FALSE)
#create corpus
TextDoc<-Corpus(VectorSource(amazon$reviewText))
inspect(TextDoc[1:5])
#cleaning the data
toSpace<-content_transformer(function(x,pattern)gsub(pattern,"",x))
TextDoc<-tm_map(TextDoc, toSpace, "/")
TextDoc<-tm_map(TextDoc, toSpace,"@")
TextDoc<-tm_map(TextDoc, toSpace,"\\|")
TextDoc <- tm_map(TextDoc, toSpace, "-")
TextDoc <- tm_map(TextDoc, toSpace, ":")
TextDoc <- tm_map(TextDoc, toSpace, ";")

#remove punctuations
TextDoc<-tm_map(TextDoc,removePunctuation)

#convert to lowercase
TextDoc<-tm_map(TextDoc,content_transformer(tolower))

#remove numbers
TextDoc<-tm_map(TextDoc,removeNumbers)

#remove whitespace
TextDoc<-tm_map(TextDoc,stripWhitespace)

#remove stopwords 
TextDoc<-tm_map(TextDoc,removeWords, stopwords("english"))
TextDoc<-tm_map(TextDoc,removeWords,"book") ### Taken from the word book is seen in most documents except document no 11,16,17 and 19. 

#stem the document
TextDoc<-tm_map(TextDoc,stemDocument)

inspect(TextDoc[1:10])

#Build Term Document Matrix to convert unstructured data into structured data
TextDoc_dtm<-TermDocumentMatrix(TextDoc)

#Convert into matrix to find out frequency of words
dtm_m<-as.matrix(TextDoc_dtm)
#let's see the first 10 rows and 20 columns
dtm_m[1:10,1:20]
#For eg. the word bet is seen only in document 1 once and does not appear thereafter
#For eg. the word book is seen in most documents except document no 11,16,17 and 19. 
# The word 'book' is very common and is of not use to us. Better to remove it. 
#Now we don't find the word 'book'

#let's sort it by decreasing frequency
dtm_v<-sort(rowSums(dtm_m),decreasing = TRUE)
#create a data frame with the names 'word' and 'freq'
dtm_d<-data.frame(word = names(dtm_v), freq = dtm_v)
#inspect the top 10 frequently occurring terms
head(dtm_d)
# word   freq
#stori  11094
#read   10779
#like    6549
#one     5952
#charact 5759
#just    5482

tail(dtm_d)
#word        freq
#backgroung    1
#firedrak      1
#gryphon       1
#helo          1
#insit         1
#relm          1

#Let's create a bar chart showing the top 5 most occurring words
barplot(dtm_d[1:5,]$freq, las = 2, names.arg = dtm_d[1:5,]$word,
       col ="green", main ="Top 5 most frequent words",
       ylab = "Word Count")

#create wordcloud
set.seed(1234)
wordcloud2(dtm_d,shape = "triangle", size = 0.5)

#Word association to find correlation between words
findAssocs(TextDoc_dtm,terms = c("stori","read","like"),corlimit = 0.2)
# stori(root word for stories) has an association with charact(root word for character) 29% of the time.
# read has an association with book (27% of time)
# like has an association with just (32% of time)
# We can change the corlimit as per our wishes to get more or less associations

#FIND SENTIMENT SCORE
sentiment_scores<-sentimentr::sentiment(amazon$reviewText)
sentiment_scores
#element_id refers to the review No (Total we have 12000 reviews)
#sentence_id (1) refers to the 1st sentence in that review. 2 refers to the 2nd sentence in the review
# word_count refers to the count of words in that sentence
# sentiment refers to the positive or negative sentiment in that sentence in that review

# Find out overall sentiment
document_polarity_score<- mean(sentiment_scores$sentiment)
document_polarity_score
#0.0789 refers to an overall positive sentiment for the reviews

#Find out sentiment for each review by clubbing element_id and word count
library(dplyr)
my_group<-sentiment_scores %>% 
  group_by(element_id) %>% 
  summarise(total_word_count = sum(word_count), avg_sentiment = mean(sentiment))

my_group

#run nrc sentiment analysis
d<-get_nrc_sentiment(amazon$reviewText)
head(d,10)

#Let's check review No 5. 
#Anger - 1 , Anticipation - 1, Joy - 3, Surprise - 1, Trust - 3, Negative - 2, Positive - 6
amazon$reviewText[5]
get_nrc_sentiment('interest')
#Out of the 6 positive sentiments for review No 5, one of them belongs to the word "interest"
get_nrc_sentiment('alive')
#Anticipation sentiment for review No 5 has only one word and that belongs to "alive"

#Let's create a bar plot for the sentiment analysis
barplot(colSums(d),
        las = 2,
        col = rainbow(10),
        ylab = 'Count',
        main = "Sentiment Scores for Amazon Kindle Reviews")
# Words associated with the sentiment "positive" appear the most number of times (more than 60000)
# Words associated with the sentiment "disgust" appear the least number of times (close to 10000)

#Let's see the percentage of each sentiment to the overall sentiment
barplot(sort(colSums(prop.table(d[1:10]))),
        horiz = TRUE,
        col = rainbow(10),
        las = 2,
        main = 'Sentiment Percentage Score',
        xlab = 'Percentage')
# The overall reviews contains "positive" sentiment in the range of 20% to 25%
# the overall reviews contains "disgust" sentiment around 4%.

