# set the working directory and read the data
melb<-read.csv("melb_data.csv")
#check column names
names(melb)
#check the data types of all the columns
str(melb)
#convert date column from character vector to date vector
library(lubridate)
melb$Date<-parse_date_time(melb$Date, orders = c("%d/%m/%Y", "%d-%m-%Y"))
str(melb$Date)
melb$Date<-as.Date(melb$Date)

melb$YearBuilt<-as.integer(melb$YearBuilt)
str(melb$YearBuilt)

#we need to create a column called age which indicates the age of the house as this may be a factor in the pricing
melb$age<- year(melb$Date) - melb$YearBuilt

#Check for missing values
sum(is.na(melb))
colSums(is.na(melb))

#remove all missing values. 11566 records have been removed
melb<-na.omit(melb)

#remove columns which are not significant
# X , suburb and address as zipcode is mentioned , type , method, SellerG, date, Car, year built, Council Area, 
#Region Name

melb1<-melb[,-c(1:3,5,7:9,14,17:18,21)]
melb1

#split the data into train and test
set.seed(1234)
index<- sample(1:nrow(melb1), 0.8*nrow(melb1))
train<- melb1[index,]
test<-melb1[-index,]

#run decision tree
library(rpart)
library(RColorBrewer)
library(rattle)
library(rpart.plot)

dtree<-rpart(Price~., data=train, method = 'anova')
options(scipen = 10)
dtree
mean(train$Price) # this indicates that the average price for 5464 houses is $1084349
# Few examples of the reading are as follows
# Where building area is less than 200.5, the average price for 4582 houses is $931445
# Where building area is less than 200.5 & age of the building is less than 67.5 years, 
# the avg price for 3385 houses is $799299.6
# $4801538 is the Highest average prices of 13 houses where distance is lower than 5.35 & building are is >280.5  

#plot the decision tree
plot(dtree)
text(dtree)
fancyRpartPlot(dtree, cex = 0.5)

#run caret package for tuning the parameter
library(caret)
set.seed(1234)
tuning_grid<-expand.grid(cp = seq(0.01,0.1,by=0.01))
tr_control<-trainControl(method = 'cv', number = 5)
model<- train(Price~., method = 'rpart', data = train, trControl = tr_control, tuneGrid = tuning_grid)
print(model)

#RMSE is 445197.9 at cp 0.01 , Rsquared is 0.57 , MAE is 287748.6 

#prediction
predicted<-predict(model, newdata = test, type ='raw')
predicted
test$predicted<-predicted

#Find out RMSE and MAPE
library(Metrics)
rmse_test<-rmse(test$Price,test$predicted)
rmse_test #392107

mape_test<-mape(test$Price,test$predicted)
mape_test #0.297 (Accuracy is 99.70%)

mae_test<-mae(test$Price,test$predicted)
mae_test # This shows that the predicted price deviates by about $272105.4 from the actual price

# Find out important variables
importance<- varImp(model)
print(importance)
# Postcode is most important , followed by longitude and building area. 
head(test)
head(test$Price)
head(test$predicted)

####### We can change the complexity parameter and see what results we get

##### RANDOM FOREST
?randomForest
library(randomForest)
set.seed(1234)
rf<-randomForest(Price~., data = train)
rf # We have used default parameters like number of trees =500
varImpPlot(rf)
# Building Area , age and Distance are the most important variables

# predict the test data
predicted1<- predict(rf, newdata = test, type = 'response')
test$predicted1<- predicted1

#Find out RMSE and MAPE
rmse_test1<- rmse(test$Price,test$predicted1)
rmse_test1 # 250426.2

mape_test1<-mape(test$Price,test$predicted1)
mape_test1 # 0.147 (Accuracy is 99.853%)

mae_test1<- mae(test$Price,test$predicted1)
mae_test1 # Predicted price deviates about $151657.7 from the actual price

### Default parameters of random forest are showing better results than the tuned parameters of decision tree

plot(rf) # After the 100th tree the line is reducing very marginally and it almost looks constant around 200
# with some minor reductions. We can choose ntree =200

# Tune the model
?tuneRF

tune_model<-tuneRF(train[,-2],train[,2], stepFactor = 2, ntreeTry = 200, plot = TRUE, improve = 0.05)
tune_model
# mtry = 3 has the lowest OOB error

set.seed(1234)
modelrf<- randomForest(Price~., data =train, mtry = 3 , ntree = 200)
modelrf


## Lets tune the model

library(caret)
set.seed(1234)
grid<-expand.grid(mtry = c(2,3,4))
ctrl<-trainControl(method = 'cv', number = 5, verboseIter = TRUE)
modelrf1<- train(Price~., data = train, method = "rf", tuneGrid = grid, trControl = ctrl,ntree=200)
# Mtry = 4 is the best mtry
predicted2<- predict(modelrf1, newdata = test, type = 'raw')
test$predicted2<- predicted2

rmse_test2 <- rmse(test$Price,test$predicted2)
rmse_test2 #252216.1

mape_test2<- mape(test$Price,test$predicted2)
mape_test2 # 0.146 (accuracy is 99.854%)

mae_test2<- mae(test$Price, test$predicted2)
mae_test2 # # Predicted price deviates about $151669.4 from the actual price



# We can conclude that the default parameter of ntree = 500 of random forest is the best model 
# as it has the lowest RMSE,MAE