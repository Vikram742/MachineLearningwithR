#set the working directory and read the data
cities<- read.csv("worldcities.csv")
dim(cities) # 26569 rows and 11 columns
names(cities)
summary(cities)
str(cities)
# We keep columns lat and lng as they seem to be the signficant columns
city<- cities[,c(3:4)]
#check for missing values
sum(is.na(city))
# No missing values found
#plot
cities<-plot(x= city$lng,y=city$lat,
             xlab = 'longitude', ylab = 'latitude', main = 'Location of all cities')

# scale the data
city1<- scale(city)
# lets find out the optimal level of clusters
library(factoextra)
library(ggplot2)

fviz_nbclust(city1,kmeans, method = 'wss')
fviz_nbclust(city1,kmeans,method = 'silhouette')



# use three clusters
set.seed(1234)
city3<- kmeans(city1, 3 , nstart = 25)
city3
#within cluster ss is 69.9%
#K-means clustering with 3 clusters of sizes 12783, 4038, 9748

# use 4 clusters
set.seed(1234)
city4<-kmeans(city1,4,nstart=25)
city4
#within cluster ss is 80.4%
#K-means clustering with 4 clusters of sizes 9847, 3336, 9704, 3682

# use 5 clusters
set.seed(1234)
city5<-kmeans(city1,5,nstart=25)
city5
#within cluster ss is 85%
#K-means clustering with 5 clusters of sizes 3305, 1682, 9737, 2159, 9686

# use 6 clusters
set.seed(1234)
city6<-kmeans(city1,6,nstart=25)
city6
#within cluster ss is 88.1%
#K-means clustering with 6 clusters of sizes 628, 1659, 9482, 3386, 9737, 1677

#use 7 clusters
set.seed(1234)
city7<- kmeans(city1,7,nstart =25)
city7
#within cluster ss is 90.1%
#K-means clustering with 7 clusters of sizes 3232, 2206, 1683, 9709, 1554, 590, 7595

fviz_cluster(city7,city1)
